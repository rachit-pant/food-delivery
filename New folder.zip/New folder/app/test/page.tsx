import AddressForm from '@/components/UserPanel/AddressForm';
import AllInfo from '@/components/UserPanel/AllInfo';
import React from 'react';

const page = () => {
  return (
    <div>
      <AddressForm />
    </div>
  );
};

export default page;
