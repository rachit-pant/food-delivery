-- AlterTable
ALTER TABLE "restaurants" ADD COLUMN     "imageurl" TEXT;
