-- AlterEnum
ALTER TYPE "roles" ADD VALUE 'admin';
