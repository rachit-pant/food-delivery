import React from 'react';

const FooterMain = () => {
  return <div>FooterMain</div>;
};

export default FooterMain;
