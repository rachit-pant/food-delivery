import React from 'react';

const AddressEnter = () => {
  return <div>AddressEnter</div>;
};

export default AddressEnter;
